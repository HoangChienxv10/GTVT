//Tichpx
#include<bits/stdc++.h>
using namespace std;
long fib(int n)
{
	long F[n+5]={1,1};  //khai bao mang F co n+5 phan tu F[0]=1,F[1]=1 cac F[2] .. =0
	for(int i=2;i<=n;i++) F[i]=F[i-1]+F[i-2];
	return F[n];
}
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<=n;i++)  cout<<"F["<<i<<"] = "<<fib(i)<<"\n";
	//cout<<fib(n);
}


