//Tichpx
#include<bits/stdc++.h>
using namespace std;
int dem=0;
map<int,bool> A,B,C;
void TRY(int *x,int k,int n) //gia su da dat duoc x1...x[k-1]
{
	if(k-1==n) 
	{
		cout<<"\n"<<setw(5)<<" "<<++dem<<" : ";
		for(int i=1;i<=n;i++) cout<<"("<<i<<","<<x[i]<<") ";
	}
	else
	{
		for(int t=1;t<=n;t++)
		if(A[t]==0 && B[k-t]==0 && C[k+t]==0)
		{
			A[t]=B[k-t]=C[k+t]=1;
			x[k]=t;
			TRY(x,k+1,n);
			A[t]=B[k-t]=C[k+t]=0;  //lui
		}	
	}	
}
int main()
{
	int x[1000],n;
	cin>>n;
	TRY(x,1,n);
}



