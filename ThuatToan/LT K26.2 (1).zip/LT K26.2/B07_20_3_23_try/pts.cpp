//Tichpx  - phan tich so
#include<bits/stdc++.h>
using namespace std;
void TRY(int *x,int k,int T,int n) //gia su da co x1+...+xk=T <=n
{
	if(T==n)
	{
		cout<<"\n"<<n<<" = "<<x[1];
		for(int i=2;i<=k;i++) cout<<"+"<<x[i];
		return;
	}
	for(x[k+1]=x[k];x[k+1]+T<=n;x[k+1]++) TRY(x,k+1,T+x[k+1],n);
}
int main()
{
	int x[100]={1},n;
	cin>>n;
	TRY(x,0,0,n);
}


