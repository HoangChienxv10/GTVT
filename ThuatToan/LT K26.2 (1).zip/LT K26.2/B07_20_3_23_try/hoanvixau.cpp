//Tichpx  - sinh hoan vi xau
#include<bits/stdc++.h>
using namespace std;
map<char,int> F;  //tan suat
int dem=0;
void TRY(string x,int n)
{
	if(x.size()==n) cout<<setw(5)<<++dem<<" : "<<x<<"\n";
	else for(auto &f:F)
	if(f.second>0)
	{
		f.second--;
		TRY(x+f.first,n);
		f.second++;
	}	
}
int main()
{
	string s;
	cin>>s;
	for(auto c:s) F[c]++; //dem tan suat
	TRY("",s.size());
}


