//Tichpx - sinh hoan vi
#include<bits/stdc++.h>
using namespace std;
int d[1000]={};  //mang danh dau
void TRY(int *x,int k,int n) //gia su co x1...x[k-1]
{
	if(k>n) {for(int i=1;i<k;i++) cout<<x[i]<<" "; cout<<"\n";return ;}
	for(int t=1;t<=n;t++)
	if(d[t]==0)
	{
		d[t]=1;     //danh dau di vao t
		x[k]=t;
		TRY(x,k+1,n);
		d[t]=0;     //bo danh dau de lui
	}
}
int main()
{
	int n,x[100];
	cin>>n;
	TRY(x,1,n);
}


