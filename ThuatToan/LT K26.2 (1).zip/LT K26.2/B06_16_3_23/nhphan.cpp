//Tichpx
#include<bits/stdc++.h>
using namespace std;
void TRY(int *x,int k,int n) //gia su da co x1...xk
{
	if(k==n) {for(int i=1;i<=n;i++) cout<<x[i]; cout<<"\n";	}
	else 
	{
		x[k+1]=0; TRY(x,k+1,n);
		x[k+1]=1; TRY(x,k+1,n);
	}
}
int main()
{
	int x[100];
	TRY(x,0,4);
}


