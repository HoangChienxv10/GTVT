//Tichpx
#include<bits/stdc++.h>
using namespace std;
int d=0;
void HN(char A,char B,char C,int n)
{
	if(n>1) HN(A,C,B,n-1);  
	cout<<"\n"<<setw(5)<<++d<<" Chuyen dia "<<n<<" tu "<<A<<" sang "<<B;
	if(n>1) HN(C,B,A,n-1);  
}
int main()
{
	int n;
	cin>>n;
	HN('A','B','C',n);

}


