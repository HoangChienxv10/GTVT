//Tichpx
#include<bits/stdc++.h>
using namespace std;

map<int,long long> D;
long long fib(int n)
{
	if(D.find(n)!=D.end()) return D[n];
	return D[n]=n<2?1:fib(n-1)+fib(n-2);
}
int main()
{
	for(int i=0;i<100;i++)
	{
		cout<<"F["<<i<<"]  =  "<<fib(i)<<"\n";
	}
}


