//Tichpx
#include<bits/stdc++.h>
using namespace std;
void tach(int n,string p="\n")
{
	if(n<=4 || n%2!=0) {cout<<p<<n; return;}
	tach((n+4)/2,p+"\t");
	cout<<p<<n;
	tach((n-4)/2,p+"\t");
}
int main()
{
	int n;
	cin>>n;
	tach(n);

}


