//Tichpx  - sang so nguyen to
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	bool s[n+5];
	fill(s+2,s+n+1,true);   //s[2]=s[3]=...=s[n]=true
	
	for(int i=2;i<=n;i++)
	if(s[i]==true)
	{
		cout<<i<<" ";
		for(int j=i*i;j<=n;j+=i) s[j]=false;
	}

}


