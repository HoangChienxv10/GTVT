//Tichpx
#include<bits/stdc++.h>
using namespace std;
double hinhthang(double a,double b,double f(double))
{
	int n=1e5;
	double h=(b-a)/n,I=f(a)+f(b);
	for(int i=1;i<n;i++) I+=2*f(a+i*h);
	return I*h/2;
}
double fun(double x) {return 4/(x*x+1);}
int main()
{
	cout<<"I1 = "<<setprecision(5)<<fixed<<hinhthang(0,acos(-1),sin);
	cout<<"\n Pi = "<<setprecision(5)<<fixed<<hinhthang(0,1,fun);
}


