//Tichpx  - counting sort
#include<bits/stdc++.h>
using namespace std;
int main()
{
	char x[10000];
	cin>>x;
	int d[300]={};  //d[0]=d[1]=...=d[25]=0
	for(char *p=x;*p!='\0';p++) d[*p]++;  //dem tan suat
	for(char *p=x,c='a';c<='z';c++)
		while(d[c]--) *p++=c;
	cout<<x;
}


