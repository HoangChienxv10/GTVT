//Tichpx   - tim diem tren doan gan diem cho truoc
#include<bits/stdc++.h>
using namespace std;
#define x first
#define y second
double bpkc(pair<double,double> A,pair<double,double> B)
{
	return (A.x-B.x)*(A.x-B.x)+ (A.y-B.y)*(A.y-B.y); 
}
int main()
{
	pair<double,double> A,B,C,M;
	cin>>A.x>>A.y;
	cin>>B.x>>B.y;
	cin>>M.x>>M.y;
	while(abs(A.x-B.x)>1e-4 or abs(A.y-B.y)>1e-4)
	{
		C={(A.x+B.x)/2,(A.y+B.y)/2};
		if(bpkc(A,M)>bpkc(B,M)) A=C;
		else B=C;
	}
	cout<<setprecision(4)<<fixed<<A.x<<" "<<A.y;
}


