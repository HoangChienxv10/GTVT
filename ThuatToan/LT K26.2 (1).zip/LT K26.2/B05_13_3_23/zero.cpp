//Tichpx -- moi con duong ve 0
#include<bits/stdc++.h>
using namespace std;
struct ss{int operator()(pair<int,int>u, pair<int,int> v) {return u.second>v.second;}};
int A_star(int s,int f)
{
	priority_queue< pair<int,int>, vector<pair<int,int>>, ss> Q;
	int L[s+5]={};
	fill(L,L+s,1e9);  
	Q.push({s,0});
	while(Q.size())
	{
		pair<int,int> u=Q.top();Q.pop();
		if(u.first==f) return u.second;
		for(int a=1;a*a<=u.first;a++)
		if(u.first%a==0)
		{
			int b=u.first/a;
			int v=(a-1)*(b+1);
			int p=u.second+(b%a==0?b/a:b+a);
			if(v>=f && L[v]>p){	L[v]=p;	Q.push({v,p});	} 
		}
	}
	return -1;
}
int main()
{
	int s,f;
	cin>>s>>f;
	int res=A_star(s,f);
	if(res==-1) cout<<"khong di duoc";
	else cout<<"chi phi it nhat "<<res;
}


