//Tichpx
#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<int> A(3,5);
	A.push_back(6);
	A.front()=8;
	for(auto a:A) cout<<a<<" ";

}


