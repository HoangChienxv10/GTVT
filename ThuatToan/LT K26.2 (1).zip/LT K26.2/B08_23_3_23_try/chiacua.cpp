//Tichpx - chia cua
#include<bits/stdc++.h>
using namespace std;
struct cua
{
	int n,a[1000],res=INT_MAX;
	void sol()
	{
		cin>>n;
		for(int i=1;i<=n;i++) cin>>a[i];
		TRY(0,0,0);
		cout<<res;
	}
	void TRY(int k,int A,int B) //da chia xong k do vat tong 1 la A, tong 2 la B
	{
		if(k==n) res=min(res,abs(A-B));
		else
		{
			TRY(k+1,A+a[k+1],B);
			TRY(k+1,A,B+a[k+1]);
		}
	}
};
int main(){ cua C; C.sol();}


