//Tichpx
#include<bits/stdc++.h>
using namespace std;
struct money
{
	int n,M,x[100],a[100],res=INT_MAX;
	void sol()
	{
		cin>>n>>M;
		for(int i=1;i<=n;i++) cin>>a[i];
		TRY(0,0,0);
		if(res==INT_MAX) cout<<"khong doi duoc";
		else cout<<"\nSo to it nhat "<<res;
	}
	void TRY(int k,int t,int T) //gia su doi duoc k loai tong to t tong tien T
	{
		if(k==n-1)
		{
			if((M-T)%a[n]==0) res=min(res,t+(M-T)/a[n]);
		}
		else 
		{
			for(int z=0;z+t<res && T+a[k+1]*z<=M;z++)
			{
				x[k+1]=z;
				TRY(k+1,t+z,T+a[k+1]*z);
			}
		}
	}
};
int main(){money M; M.sol();}


