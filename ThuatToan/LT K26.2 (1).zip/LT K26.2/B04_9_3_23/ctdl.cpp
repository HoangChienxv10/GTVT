//Tichpx
#include<bits/stdc++.h>
using namespace std;
int main()
{
	//priority_queue<int> Q;
	priority_queue<int,vector<int>, greater<int> > Q;
	for(int x:{432,65,36,54,754,653,72}) Q.push(x);
	
	while(Q.size())
	{
		cout<<Q.top()<<" ";
		Q.pop();
	}

}


