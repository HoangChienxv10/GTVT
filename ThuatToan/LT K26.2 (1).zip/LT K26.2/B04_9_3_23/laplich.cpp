//Tichpx lap lich
#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> viec;
bool ss(viec u,viec v) {return u.second<v.second;}
int main()
{
	int n,t=-INT_MAX,res=0;
	cin>>n;
	viec A[n];
	for(auto &a:A) cin>>a.first>>a.second;
	sort(A,A+n,ss);
	for(auto a:A)
	if(a.first>=t) 
	{
		res++;
		t=a.second;
	}
	cout<<res;
//	cout<<"\nsau khi sap xep : ";
//	for(auto a:A) cout<<a.first<<" "<<a.second<<"\n";
}


