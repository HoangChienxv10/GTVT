//Tichpx
#include<bits/stdc++.h>
using namespace std;
int main()
{
	long n;
	cin>>n;
	long a[n+5],C[n+5];
	for(int i=1;i<=n;i++) cin>>a[i];
	C[1]=a[1];
	for(int i=2;i<=n;i++) C[i]=max(C[i-1],0L)+a[i];
	cout<<*max_element(C+1,C+n+1);
}


