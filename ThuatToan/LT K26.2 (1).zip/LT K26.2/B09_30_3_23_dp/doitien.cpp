//Tichpx
#include<bits/stdc++.h>
using namespace std;
class money
{
	int n,M,a[100],C[100][1000]={};
	public: void sol()
	{
		cin>>n>>M;
		for(int i=1;i<=n;i++) cin>>a[i];
		for(int j=1;j<=M;j++) C[0][j]=1e9;  //10^9 la vo cung
		for(int i=1;i<=n;i++) 
		for(int j=1;j<=M;j++)
		if(j<a[i]) C[i][j]=C[i-1][j];
		else C[i][j]=min(C[i-1][j],1+C[i][j-a[i]]);
		if(C[n][M]==1e9) cout<<"khong doi duoc";
		else
		{
			cout<<"\nSo to it nhat "<<C[n][M]<<" gom : ";
			TRACE(n,M);
		}
	}
	void TRACE(int n,int M)
	{
		if(C[n][M]==0) return;
		while(C[n][M]==C[n-1][M]) n--;
		TRACE(n,M-a[n]);
		cout<<a[n]<<" ";
	}
};
int main(){money M; M.sol();}


